import pygame
from pygame.locals import *
import os
import random
import math

pygame.init()

#screen size
screen_width = 800
screen_height = 600

clock = pygame.time.Clock()
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("WHAT")

tile_size = 32


# ───────────────── PLAYER ─────────────────
class Player(pygame.sprite.Sprite):
    def __init__(self, PLAYER_X, PLAYER_Y):
        super().__init__()

        self.start_x = PLAYER_X
        self.start_y = PLAYER_Y

        self.player_static_r = pygame.transform.scale(
            pygame.image.load(os.path.join("image_s", "static.png")), (32, 36)
        )

        self.player_moving_r = [
            pygame.transform.scale(pygame.image.load(os.path.join("image_s", "move_1.png")), (32, 36)),
            pygame.transform.scale(pygame.image.load(os.path.join("image_s", "move_2.png")), (32, 36)),
            pygame.transform.scale(pygame.image.load(os.path.join("image_s", "move_3.png")), (32, 36)),
            pygame.transform.scale(pygame.image.load(os.path.join("image_s", "move_4.png")), (32, 36)),
        ]

        self.player_static_l = pygame.transform.flip(self.player_static_r, True, False)
        self.player_moving_l = [pygame.transform.flip(img, True, False) for img in self.player_moving_r]

        self.image = self.player_moving_r[1]

        self.rect = pygame.Rect(PLAYER_X, PLAYER_Y, 17, 36)

        self.VELOCITY_Y = 0
        self.VELOCITY_X = 0

        self.direction = "right"
        self.state = "static"

        self.frame_index = 0
        self.animation_speed = 0.20

    def movement(self, world):
        keys = pygame.key.get_pressed()
        self.moving = False
        self.VELOCITY_X = 0

        if keys[K_LEFT]:
            self.VELOCITY_X -= 5
            self.direction = "left"
            self.moving = True

        if keys[K_RIGHT]:
            self.VELOCITY_X += 5
            self.direction = "right"
            self.moving = True

        # X move
        self.rect.x += self.VELOCITY_X
        self.check_collision_x(world)

        # gravity
        self.VELOCITY_Y += 0.8
        if self.VELOCITY_Y > 10:
            self.VELOCITY_Y = 10

        self.rect.y += self.VELOCITY_Y
        self.check_collision_y(world)

        # state
        if self.VELOCITY_Y != 0:
            self.state = "jump"
        elif self.moving:
            self.state = "walk"
        else:
            self.state = "static"

        # animation
        if self.state != "walk":
            self.frame_index = 0

        if self.state == "walk":
            self.frame_index += self.animation_speed
            if self.frame_index >= len(self.player_moving_r):
                self.frame_index = 0

            if self.direction == "right":
                self.image = self.player_moving_r[int(self.frame_index)]
            else:
                self.image = self.player_moving_l[int(self.frame_index)]

        elif self.state == "jump":
            self.image = self.player_moving_r[1] if self.direction == "right" else self.player_moving_l[1]

        else:
            self.image = self.player_static_r if self.direction == "right" else self.player_static_l

    def check_collision_x(self, world):
        for tile in world.platforms:
            if self.rect.colliderect(tile.rect):
                if self.VELOCITY_X > 0:
                    self.rect.right = tile.rect.left
                elif self.VELOCITY_X < 0:
                    self.rect.left = tile.rect.right

    def check_collision_y(self, world):
        for tile in world.platforms:
            if self.rect.colliderect(tile.rect):
                if self.VELOCITY_Y > 0:
                    self.rect.bottom = tile.rect.top
                    self.VELOCITY_Y = 0
                elif self.VELOCITY_Y < 0:
                    self.rect.top = tile.rect.bottom
                    self.VELOCITY_Y = 0

    
    def reset(self):
        self.rect.x = self.start_x
        self.rect.y = self.start_y
        self.VELOCITY_X = 0
        self.VELOCITY_Y = 0


# ───────────────── TILE ─────────────────
class Tile(pygame.sprite.Sprite):
    def __init__(self, x, y, image):
        super().__init__()
        self.image = image
        self.rect = image.get_rect(topleft=(x, y))


# ───────────────── FALLING BLOCK ─────────────────
class Falling_Block(Tile):
    def __init__(self, x, y, image, fall_speed):
        super().__init__(x, y, image)
        self.fall_speed = fall_speed
        self.falling = False
        self.trigger_range = 50

    def update(self, player):
        if abs(player.rect.centerx - self.rect.centerx) <= self.trigger_range:
            self.falling = True

        if self.falling:
            self.rect.y += self.fall_speed


# ───────────────── SPIKE ─────────────────
class Spike(pygame.sprite.Sprite):
    def __init__(self, x, y, image):
        super().__init__()
        self.image = image

        # FIXED: correct hitbox position
        self.rect = pygame.Rect(x, y + (32 - 7), 32, 7)

    def update(self, player):
        if self.rect.colliderect(player.rect):
            player.reset()


# ───────────────── WORLD ─────────────────
class World():
    def __init__(self, data):
        self.platforms = pygame.sprite.Group()
        self.falling_blocks = pygame.sprite.Group()
        self.spikes = pygame.sprite.Group()

        tile_surface = pygame.Surface((tile_size, tile_size))
        tile_surface.fill("#003a49")

        tile_spike = pygame.transform.scale(
            pygame.image.load(os.path.join("image_s", "spike_static.png")), (32, 7)
        )

        for row_index, row in enumerate(data):
            for column_index, tile_type in enumerate(row):

                x = column_index * tile_size
                y = row_index * tile_size

                if tile_type == 1:
                    self.platforms.add(Tile(x, y, tile_surface))

                elif tile_type == 2:
                    self.falling_blocks.add(Falling_Block(x, y, tile_surface, 5))

                elif tile_type == 3:
                    self.spikes.add(Spike(x, y, tile_spike))

    def draw(self):
        self.platforms.draw(screen)
        self.falling_blocks.draw(screen)
        self.spikes.draw(screen)

    def update(self, player):
        self.falling_blocks.update(player)
        self.spikes.update(player)


# ───────────────── LEVEL ─────────────────
world_data = [
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,0,1,3,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,1,1,1,1,1,1,1,1,1,1,1,2,1,1,1,1,1,1,1,1,1,1,1,1],
    [1,1,1,1,1,1,1,1,1,1,1,1,2,1,1,1,1,1,1,1,1,1,1,1,1],
]


player = Player(150, 200)
world = World(world_data)


# ───────────────── MAIN LOOP ─────────────────
run = True
while run:

    screen.fill("#0088aa")

    player.movement(world)
    world.update(player)

    world.draw()
    screen.blit(player.image, player.rect)

    for event in pygame.event.get():
        if event.type == QUIT:
            run = False

        if event.type == KEYDOWN:
            if event.key == K_SPACE and player.VELOCITY_Y == 0:
                player.VELOCITY_Y = -14

    pygame.display.update()
    clock.tick(60)

pygame.quit()