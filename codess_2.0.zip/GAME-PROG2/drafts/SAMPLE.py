import pygame
from pygame.locals import *
import os
import random
import math

pygame.init()

# screen size
screen_width  = 1280
screen_height = 720

clock  = pygame.time.Clock()
screen = pygame.display.set_mode((screen_width, screen_height), pygame.FULLSCREEN | pygame.SCALED)
pygame.display.set_caption("WHAT")

tile_size = 40


# ================================================================== #
#  DEATH PARTICLE
# ================================================================== #
class DeathParticle:
    def __init__(self, x, y, angle, speed):
        self.x          = x
        self.y          = y
        self.VELOCITY_X = math.cos(angle) * speed
        self.VELOCITY_Y = math.sin(angle) * speed
        self.chunk_size = random.randint(3, 5)
        self.color      = (0, 0, 0)
        self.active     = True

    def update(self, platforms):
        if not self.active:
            return
        self.x += self.VELOCITY_X
        pr = pygame.Rect(int(self.x), int(self.y), self.chunk_size, self.chunk_size)
        for tile in platforms:
            if pr.colliderect(tile.rect):
                if self.VELOCITY_X > 0: self.x = tile.rect.left - self.chunk_size
                elif self.VELOCITY_X < 0: self.x = tile.rect.right
                break
        self.y += self.VELOCITY_Y
        pr = pygame.Rect(int(self.x), int(self.y), self.chunk_size, self.chunk_size)
        for tile in platforms:
            if pr.colliderect(tile.rect):
                if self.VELOCITY_Y > 0:
                    self.y = tile.rect.top - self.chunk_size
                    self.VELOCITY_Y = 0
                    self.VELOCITY_X *= 0.6
                elif self.VELOCITY_Y < 0:
                    self.y = tile.rect.bottom
                    self.VELOCITY_Y = 0
                break
        self.VELOCITY_Y += 0.6
        if self.VELOCITY_Y > 12: self.VELOCITY_Y = 12
        self.VELOCITY_X *= 1.1
        if self.y > screen_height + 50: self.active = False

    def draw(self, surface):
        if self.active:
            pygame.draw.rect(surface, self.color,
                             (int(self.x), int(self.y), self.chunk_size, self.chunk_size))


# ================================================================== #
#  PLAYER
# ================================================================== #
class Player(pygame.sprite.Sprite):
    def __init__(self, PLAYER_X, PLAYER_Y):
        super().__init__()
        self.start_x = PLAYER_X
        self.start_y = PLAYER_Y

        self.player_static_r = pygame.transform.scale(
            pygame.image.load(os.path.join("image_s", "static.png")), (32, 36))
        self.player_moving_r = [
            pygame.transform.scale(pygame.image.load(os.path.join("image_s", f"move_{i}.png")), (32, 36))
            for i in range(1, 5)
        ]
        self.player_static_l = pygame.transform.flip(self.player_static_r, True, False)
        self.player_moving_l = [pygame.transform.flip(img, True, False) for img in self.player_moving_r]

        self.image  = self.player_moving_r[1]
        self.rect   = pygame.Rect(0, 0, 17, 36)
        self.rect.x = PLAYER_X
        self.rect.y = PLAYER_Y

        self.VELOCITY_Y      = 0
        self.VELOCITY_X      = 0
        self.direction       = "right"
        self.state           = "static"
        self.frame_index     = 0
        self.animation_speed = 0.20
        self.dead            = False
        self.death_triggered = False
        self.particles       = []
        self.alpha           = 255
        self.fading          = False

    def spawn_particles(self):
        for i in range(20):
            angle  = (2 * math.pi / 20) * i + random.uniform(-0.15, 0.15)
            speed  = random.uniform(2.5, 9.0)
            sx     = self.rect.x + random.randint(0, self.rect.width - 1)
            sy     = self.rect.y + random.randint(0, self.rect.height - 1)
            self.particles.append(DeathParticle(sx, sy, angle, speed))

    def movement(self, world):
        if self.dead:
            if not self.death_triggered:
                self.spawn_particles()
                self.death_triggered = True
                self.alpha = 0
            return

        keys        = pygame.key.get_pressed()
        self.moving = False
        self.VELOCITY_X = 0

        if keys[pygame.K_LEFT]:
            self.VELOCITY_X -= 3.5; self.direction = "left";  self.moving = True
        if keys[pygame.K_RIGHT]:
            self.VELOCITY_X += 3.5; self.direction = "right"; self.moving = True

        self.rect.x += self.VELOCITY_X
        self.check_collision_x(world)
        self.VELOCITY_Y += 0.8
        if self.VELOCITY_Y > 10: self.VELOCITY_Y = 10
        self.rect.y += self.VELOCITY_Y
        self.check_collision_y(world)

        if self.rect.bottom > screen_height: self.dead = True

        if   self.VELOCITY_Y != 0: self.state = "jump"
        elif self.moving:           self.state = "walk"
        else:                       self.state = "static"

        if self.state != "walk": self.frame_index = 0

        if self.state == "walk":
            self.frame_index += self.animation_speed
            if self.frame_index >= 4: self.frame_index = 0
            frames = self.player_moving_r if self.direction == "right" else self.player_moving_l
            self.image = frames[int(self.frame_index)]
        elif self.state == "jump":
            frames = self.player_moving_r if self.direction == "right" else self.player_moving_l
            self.image = frames[1]
        else:
            self.frame_index = 0
            self.image = self.player_static_r if self.direction == "right" else self.player_static_l

    def check_collision_x(self, world):
        for tile in world.platforms:
            if self.rect.colliderect(tile.rect):
                if self.VELOCITY_X > 0: self.rect.right = tile.rect.left
                elif self.VELOCITY_X < 0: self.rect.left = tile.rect.right

    def check_collision_y(self, world):
        for tile in world.platforms:
            if self.rect.colliderect(tile.rect):
                if self.VELOCITY_Y > 0:
                    self.rect.bottom = tile.rect.top;  self.VELOCITY_Y = 0
                elif self.VELOCITY_Y < 0:
                    self.rect.top = tile.rect.bottom; self.VELOCITY_Y = 0

    def draw(self, surface):
        ix  = self.rect.x - (self.image.get_width()  - self.rect.width)  // 2
        iy  = self.rect.y - (self.image.get_height() - self.rect.height) // 2
        img = self.image.copy()
        img.set_alpha(self.alpha)
        surface.blit(img, (ix, iy))

    def reset(self):
        self.rect.x = self.start_x; self.rect.y = self.start_y
        self.VELOCITY_X = 0;        self.VELOCITY_Y = 0
        self.state           = "static"
        self.dead            = False
        self.death_triggered = False
        self.particles       = []
        self.alpha           = 255
        self.fading          = False


# ================================================================== #
#  TILES
# ================================================================== #
class Tile(pygame.sprite.Sprite):
    def __init__(self, rect_x, rect_y, image):
        super().__init__()
        self.image  = image
        self.rect   = image.get_rect()
        self.rect.x = rect_x
        self.rect.y = rect_y


class Falling_Block(Tile):
    def __init__(self, rect_x, rect_y, image, fall_speed):
        super().__init__(rect_x, rect_y, image)
        self.fall_speed    = fall_speed
        self.falling       = False
        self.trigger_range = 50
        self.start_y       = rect_y

    def update(self, player):
        if abs(player.rect.centerx - self.rect.centerx) <= self.trigger_range:
            self.falling = True
        if self.falling:
            self.rect.y += self.fall_speed


class Spike(pygame.sprite.Sprite):
    def __init__(self, rect_x, rect_y, image):
        super().__init__()
        self.image = image
        self.rect  = pygame.Rect(rect_x, rect_y + (40 - 7), 40, 7)

    def update(self, player):
        if self.rect.colliderect(player.rect):
            player.dead = True


class Door(pygame.sprite.Sprite):
    def __init__(self, rect_x, rect_y):
        super().__init__()
        self.image  = pygame.transform.scale(
            pygame.image.load(os.path.join("image_s", "door.png")), (tile_size, tile_size))
        self.rect   = self.image.get_rect()
        self.rect.x = rect_x
        self.rect.y = rect_y
        self.active      = True
        self.enter_range = 10

    def update(self, player, door_with_player):
        if not self.active: return
        dx = abs(player.rect.centerx - self.rect.centerx)
        dy = abs(player.rect.centery - self.rect.centery)
        if dx <= self.enter_range and dy <= self.enter_range and player.rect.bottom <= self.rect.bottom:
            self.active  = False
            player.alpha = 0
            door_with_player.activate(self.rect.x, self.rect.y)

    def draw(self, surface):
        if self.active:
            surface.blit(self.image, self.rect)


class DoorWithPlayer:
    def __init__(self):
        self.image = pygame.transform.scale(
            pygame.image.load(os.path.join("image_s", "door_player.png")), (tile_size, tile_size))
        self.rect        = self.image.get_rect()
        self.active      = False
        self.sinking     = False
        self.sink_speed  = 0.8
        self.sink_target = 0
        self.done        = False

    def activate(self, rx, ry):
        self.rect.x = rx; self.rect.y = ry
        self.active  = True; self.sinking = True
        self.sink_target = self.rect.y + self.rect.height
        self.done = False

    def update(self):
        if not self.active or not self.sinking: return
        self.rect.y += self.sink_speed
        if self.rect.y >= self.sink_target:
            self.rect.y  = self.sink_target
            self.sinking = False
            self.done    = True

    def draw(self, surface):
        if self.active: surface.blit(self.image, self.rect)

    def reset(self):
        self.active = False; self.sinking = False; self.done = False


# ================================================================== #
#  WORLD
# ================================================================== #
class World:
    def __init__(self, data):
        self.platforms        = pygame.sprite.Group()
        self.falling_blocks   = pygame.sprite.Group()
        self.spikes           = pygame.sprite.Group()
        self.door             = pygame.sprite.Group()
        self.door_with_player = DoorWithPlayer()

        tile_surf  = pygame.Surface((tile_size, tile_size)); tile_surf.fill("#003a49")
        tile_spike = pygame.transform.scale(
            pygame.image.load(os.path.join("image_s", "spike_static.png")), (40, 7))

        for ri, row in enumerate(data):
            for ci, t in enumerate(row):
                rx = ci * tile_size; ry = ri * tile_size
                if   t == 1: self.platforms.add(Tile(rx, ry, tile_surf))
                elif t == 2: self.falling_blocks.add(Falling_Block(rx, ry, tile_surf, 50))
                elif t == 3: self.spikes.add(Spike(rx, ry, tile_spike))
                elif t == 4: self.door.add(Door(rx, ry))

    def draw(self):
        self.falling_blocks.draw(screen)
        self.spikes.draw(screen)
        self.door_with_player.draw(screen)
        self.platforms.draw(screen)
        for d in self.door: d.draw(screen)

    def update(self, player):
        self.falling_blocks.update(player)
        self.spikes.update(player)
        for d in self.door: d.update(player, self.door_with_player)
        self.door_with_player.update()

    def reset(self):
        for b in self.falling_blocks: b.rect.y = b.start_y; b.falling = False
        for d in self.door: d.active = True
        self.door_with_player.reset()


# ================================================================== #
#  LEVEL DATA  — replace level_2 … level_7 with your own grids
# ================================================================== #
level_1 = [
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,4,0,1],
    [1,1,1,1,1,1,1,2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,1,1,1],
    [1,1,1,1,1,1,1,2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,1,1,1],
    [1,1,1,1,1,1,1,2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,1,1,1],
    [1,1,1,1,1,1,1,2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,1,1,1],
    [1,1,1,1,1,1,1,2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,1,1,1],
    [1,1,1,1,1,1,1,2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,1,1,1],
    [1,1,1,1,1,1,1,2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,1,1,1],
    [1,1,1,1,1,1,1,2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,1,1,1],
    [1,1,1,1,1,1,1,2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,1,1,1],
    [1,1,1,1,1,1,1,2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,1,1,1],
]
level_2 = level_1
level_3 = level_1
level_4 = level_1
level_5 = level_1
level_6 = level_1
level_7 = level_1

level_worlds = [level_1, level_2, level_3, level_4, level_5, level_6, level_7]
level_spawns = [(150, 200)] * 7


# ================================================================== #
#  LOADING SCREEN
# ================================================================== #
class LoadingScreen:
    """Player runs along the top of a loading bar that fills up."""

    def __init__(self):
        self.done       = False
        self.progress   = 0.0        # 0.0 → 1.0
        self.fill_speed = 0.008      # how fast the bar fills per frame

        # Fonts
        self.font_title = pygame.font.SysFont("couriernew", 60, bold=True)
        self.font_small = pygame.font.SysFont("couriernew", 18)

        # Load player sprites
        self.frames_r = [
            pygame.transform.scale(
                pygame.image.load(os.path.join("image_s", f"move_{i}.png")), (32, 36))
            for i in range(1, 5)
        ]
        self.frames_l  = [pygame.transform.flip(f, True, False) for f in self.frames_r]
        self.frame_idx = 0.0
        self.direction = "right"

        # Bar geometry
        self.bar_x = 160
        self.bar_y = screen_height // 2 + 60
        self.bar_w = screen_width  - 320
        self.bar_h = 18

        # Player rides on top of bar
        self.player_y = self.bar_y - 36 - 2   # sits on the bar surface

        # Background colour
        self.C_BG    = (5, 18, 25)
        self.C_TITLE = (0, 200, 240)
        self.C_BAR_BG= (20, 50, 62)
        self.C_BAR   = (0, 170, 210)
        self.C_BORDER= (0, 80, 100)

        # Dots for "loading…" animation
        self.dot_timer = 0
        self.dot_count = 0

        # Optional background image
        try:
            self.bg = pygame.transform.scale(
                pygame.image.load(os.path.join("image_s", "menu_bg.png")),
                (screen_width, screen_height))
        except:
            self.bg = None

    def update(self):
        if self.done:
            return

        self.progress = min(1.0, self.progress + self.fill_speed)

        # Animate player walk
        self.frame_idx = (self.frame_idx + 0.18) % 4

        # Dot animation
        self.dot_timer += 1
        if self.dot_timer >= 20:
            self.dot_count = (self.dot_count + 1) % 4
            self.dot_timer = 0

        if self.progress >= 1.0:
            self.done = True

    def draw(self, surface):
        # Background
        if self.bg:
            surface.blit(self.bg, (0, 0))
            dim = pygame.Surface((screen_width, screen_height), pygame.SRCALPHA)
            dim.fill((0, 0, 0, 160))
            surface.blit(dim, (0, 0))
        else:
            surface.fill(self.C_BG)

        # Title
        title = self.font_title.render("WHAT", True, self.C_TITLE)
        surface.blit(title, (screen_width // 2 - title.get_width() // 2,
                             screen_height // 2 - 110))

        # Loading bar background
        pygame.draw.rect(surface, self.C_BAR_BG,
                         (self.bar_x, self.bar_y, self.bar_w, self.bar_h), border_radius=6)
        pygame.draw.rect(surface, self.C_BORDER,
                         (self.bar_x, self.bar_y, self.bar_w, self.bar_h), 2, border_radius=6)

        # Filled portion
        filled_w = int(self.bar_w * self.progress)
        if filled_w > 0:
            pygame.draw.rect(surface, self.C_BAR,
                             (self.bar_x, self.bar_y, filled_w, self.bar_h), border_radius=6)

        # Player sprite on top of bar
        player_x = self.bar_x + filled_w - 16   # centred on the fill edge
        player_x = max(self.bar_x, min(player_x, self.bar_x + self.bar_w - 32))
        frames   = self.frames_r if self.direction == "right" else self.frames_l
        surface.blit(frames[int(self.frame_idx)], (player_x, self.player_y))

        # "LOADING…" text
        dots   = "." * self.dot_count
        label  = self.font_small.render(f"LOADING{dots}", True, (80, 150, 170))
        surface.blit(label, (screen_width // 2 - label.get_width() // 2,
                             self.bar_y + self.bar_h + 18))

        # Percentage
        pct = self.font_small.render(f"{int(self.progress * 100)}%", True, (60, 120, 140))
        surface.blit(pct, (self.bar_x + self.bar_w + 10, self.bar_y))


# ================================================================== #
#  START MENU
# ================================================================== #
class StartMenu:
    def __init__(self):
        self.active         = True
        self.current_screen = "main"

        self.options  = ["PLAY", "MECHANICS", "DEVELOPERS", "QUIT"]
        self.selected = 0

        self.font_title    = pygame.font.SysFont("couriernew", 72, bold=True)
        self.font_option   = pygame.font.SysFont("couriernew", 28, bold=True)
        self.font_body     = pygame.font.SysFont("couriernew", 16)
        self.font_back     = pygame.font.SysFont("couriernew", 18, bold=True)
        self.font_door_num = pygame.font.SysFont("couriernew", 13, bold=True)

        self.C_BG     = (5,   18,  25)
        self.C_TITLE  = (0,   200, 240)
        self.C_SELECT = (255, 255, 255)
        self.C_IDLE   = (80,  140, 160)
        self.C_ARROW  = (0,   200, 240)
        self.C_BODY   = (160, 210, 220)
        self.C_BORDER = (0,   80,  100)
        self.C_HINT   = (60,  110, 130)

        try:
            self.bg = pygame.transform.scale(
                pygame.image.load(os.path.join("image_s", "menu_bg.png")),
                (screen_width, screen_height))
        except:
            self.bg = None

        self.overlay = pygame.Surface((screen_width, screen_height))
        self.overlay.fill(self.C_BG)

        # Door sprites — used on the level select screen
        try:
            self.door_img = pygame.transform.scale(
                pygame.image.load(os.path.join("image_s", "door.png")), (64, 72))
        except:
            self.door_img = None

        # Pathway / ground sprite tiled under doors
        try:
            self.path_img = pygame.transform.scale(
                pygame.image.load(os.path.join("image_s", "spike_static.png")), (40, 40))
        except:
            self.path_img = None

        self.levels = [
            {"label": "1", "locked": False},
            {"label": "2", "locked": True},
            {"label": "3", "locked": True},
            {"label": "4", "locked": True},
            {"label": "5", "locked": True},
            {"label": "6", "locked": True},
            {"label": "7", "locked": True},
        ]
        self.selected_level = 0
        self.current_level  = 0
        self.start_game     = False

        self.blink_timer = 0
        self.show_arrow  = True

        self.alpha      = 255
        self.fading     = False
        self.fade_speed = 8

        self.mechanics_lines = [
            ("MOVEMENT",    "Arrow Left / Right  —  Move"),
            ("JUMP",        "Spacebar  —  Jump"),
            ("DOOR",        "Reach the door to clear the level"),
            ("SPIKES",      "Touch spikes = instant death"),
            ("FALL BLOCKS", "Walk near them and they drop"),
            ("RESPAWN",     "Press ENTER after dying to retry"),
        ]
        self.dev_lines = [
            "DEVELOPED BY", "",
            "[ your name here ]", "",
            "Built with  Python + Pygame", "",
            "Art, Code & Design",
            "— the team —",
        ]

    # ---------------------------------------------------------------- #
    def handle_input(self, event):
        if not self.active or self.fading:
            return False

        if self.current_screen == "main":
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP:
                    self.selected = (self.selected - 1) % len(self.options)
                elif event.key == pygame.K_DOWN:
                    self.selected = (self.selected + 1) % len(self.options)
                elif event.key in (pygame.K_RETURN, pygame.K_SPACE):
                    self._confirm_main()

        elif self.current_screen == "levels":
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    self.selected_level = (self.selected_level - 1) % len(self.levels)
                elif event.key == pygame.K_RIGHT:
                    self.selected_level = (self.selected_level + 1) % len(self.levels)
                elif event.key in (pygame.K_RETURN, pygame.K_SPACE):
                    if not self.levels[self.selected_level]["locked"]:
                        self.current_level = self.selected_level
                        self.start_game    = True
                        self.fading        = True
                elif event.key in (pygame.K_ESCAPE, pygame.K_BACKSPACE):
                    self.current_screen = "main"

        elif self.current_screen in ("mechanics", "developers"):
            if event.type == pygame.KEYDOWN:
                if event.key in (pygame.K_ESCAPE, pygame.K_BACKSPACE, pygame.K_RETURN):
                    self.current_screen = "main"

        return True

    def _confirm_main(self):
        c = self.options[self.selected]
        if   c == "PLAY":       self.current_screen = "levels"
        elif c == "MECHANICS":  self.current_screen = "mechanics"
        elif c == "DEVELOPERS": self.current_screen = "developers"
        elif c == "QUIT":       pygame.quit(); exit()

    def unlock_level(self, idx):
        if idx + 1 < len(self.levels):
            self.levels[idx + 1]["locked"] = False

    def reopen(self):
        self.active         = True
        self.fading         = False
        self.alpha          = 255
        self.start_game     = False
        self.current_screen = "levels"

    # ---------------------------------------------------------------- #
    def update(self):
        if not self.active: return
        self.blink_timer += 1
        if self.blink_timer >= 30:
            self.show_arrow  = not self.show_arrow
            self.blink_timer = 0
        if self.fading:
            self.alpha -= self.fade_speed
            if self.alpha <= 0:
                self.alpha  = 0
                self.active = False

    # ---------------------------------------------------------------- #
    def draw(self, surface):
        if not self.active: return
        self._blit_bg(surface)
        if   self.current_screen == "main":       self._draw_main(surface)
        elif self.current_screen == "levels":     self._draw_levels(surface)
        elif self.current_screen == "mechanics":  self._draw_mechanics(surface)
        elif self.current_screen == "developers": self._draw_developers(surface)

    def _blit_bg(self, surface):
        if self.bg:
            b = self.bg.copy(); b.set_alpha(self.alpha); surface.blit(b, (0, 0))
        else:
            self.overlay.set_alpha(self.alpha); surface.blit(self.overlay, (0, 0))

    # ---- MAIN -------------------------------------------------------- #
    def _draw_main(self, surface):
        dim = pygame.Surface((screen_width, screen_height), pygame.SRCALPHA)
        dim.fill((0, 0, 0, 135)); dim.set_alpha(self.alpha); surface.blit(dim, (0, 0))

        t = self.font_title.render("WHAT", True, self.C_TITLE)
        t.set_alpha(self.alpha)
        surface.blit(t, (screen_width // 2 - t.get_width() // 2, 95))
        pygame.draw.line(surface, self.C_BORDER,
                         (screen_width//2-140, 190), (screen_width//2+140, 190), 2)

        pw, ph = 280, 245
        px, py = screen_width//2 - pw//2, 210
        panel  = pygame.Surface((pw, ph), pygame.SRCALPHA)
        panel.fill((5, 20, 30, 215)); panel.set_alpha(self.alpha); surface.blit(panel, (px, py))
        pygame.draw.rect(surface, self.C_BORDER, (px, py, pw, ph), 2)

        for i, opt in enumerate(self.options):
            oy    = py + 22 + i * 52
            color = self.C_SELECT if i == self.selected else self.C_IDLE
            if i == self.selected:
                bar = pygame.Surface((pw - 4, 42), pygame.SRCALPHA)
                bar.fill((0, 136, 170, 110)); surface.blit(bar, (px+2, oy-7))
            if i == self.selected and self.show_arrow:
                arr = self.font_option.render(">", True, self.C_ARROW)
                arr.set_alpha(self.alpha); surface.blit(arr, (px+12, oy))
            txt = self.font_option.render(opt, True, color)
            txt.set_alpha(self.alpha); surface.blit(txt, (px+42, oy))

        hint = self.font_body.render("UP / DOWN     ENTER to select", True, self.C_HINT)
        hint.set_alpha(self.alpha)
        surface.blit(hint, (screen_width//2 - hint.get_width()//2, 500))

    # ---- LEVEL SELECT ----------------------------------------------- #
    def _draw_levels(self, surface):
        self._blit_bg(surface)
        dim = pygame.Surface((screen_width, screen_height), pygame.SRCALPHA)
        dim.fill((0, 0, 0, 155)); dim.set_alpha(self.alpha); surface.blit(dim, (0, 0))

        t = self.font_option.render("SELECT LEVEL", True, self.C_TITLE)
        t.set_alpha(self.alpha)
        surface.blit(t, (screen_width//2 - t.get_width()//2, 50))
        pygame.draw.line(surface, self.C_BORDER, (60, 96), (screen_width-60, 96), 1)

        door_w = 128; door_h = 185; gap = 22
        n      = len(self.levels)
        total  = n * door_w + (n - 1) * gap
        sx     = screen_width//2 - total//2
        # ground Y — bottom of doors will sit here
        ground_y = screen_height // 2 + door_h // 2 + 30

        # ----- tiled pathway under doors -----
        path_tile_w = 40
        path_rows   = 2
        path_start  = sx - 10
        path_end    = sx + total + 10
        for row in range(path_rows):
            py_tile = ground_y + row * path_tile_w
            cx = path_start
            while cx < path_end:
                if self.path_img:
                    pi = self.path_img.copy(); pi.set_alpha(self.alpha)
                    surface.blit(pi, (cx, py_tile))
                else:
                    pygame.draw.rect(surface, (0, 58, 73), (cx, py_tile, path_tile_w, path_tile_w))
                cx += path_tile_w

        # Pathway border line
        pygame.draw.line(surface, self.C_BORDER,
                         (path_start, ground_y), (path_end, ground_y), 2)

        # ----- draw each door -----
        door_y = ground_y - door_h
        for i, lvl in enumerate(self.levels):
            dx = sx + i * (door_w + gap)
            self._draw_door(surface, dx, door_y, door_w, door_h,
                            lvl["label"], lvl["locked"], i == self.selected_level)

        hint = self.font_body.render(
            "LEFT / RIGHT  —  browse       ENTER  —  enter       ESC  —  back",
            True, self.C_HINT)
        hint.set_alpha(self.alpha)
        surface.blit(hint, (screen_width//2 - hint.get_width()//2, screen_height - 48))

    def _draw_door(self, surface, x, y, w, h, label, locked, selected):
        if locked:
            door_col  = (20,  50,  60);  frame_col = (35,  75,  90)
            spike_col = (30,  65,  78);  num_col   = (55,  95,  110)
            panel_a   = (15,  40,  52,  200)
        elif selected:
            door_col  = (0,   150, 190); frame_col = (0,   210, 255)
            spike_col = (0,   230, 255); num_col   = (255, 255, 255)
            panel_a   = (0,   55,  75,  235)
        else:
            door_col  = (0,   95,  125); frame_col = (0,   136, 170)
            spike_col = (0,   155, 195); num_col   = (150, 205, 220)
            panel_a   = (5,   38,  52,  200)

        # Glow
        if selected and not locked:
            glow = pygame.Surface((w + 28, h + 28), pygame.SRCALPHA)
            glow.fill((0, 200, 240, 38)); glow.set_alpha(self.alpha)
            surface.blit(glow, (x - 14, y - 14))

        # Card
        card = pygame.Surface((w, h), pygame.SRCALPHA)
        card.fill(panel_a); card.set_alpha(self.alpha); surface.blit(card, (x, y))
        pygame.draw.rect(surface, frame_col, (x, y, w, h), 3)

        # Spikes on top
        ns = 8; sw = w // ns; sh = 18
        for s in range(ns):
            sx2 = x + s * sw
            pts = [(sx2, y), (sx2+sw, y), (sx2+sw//2, y-sh)]
            pygame.draw.polygon(surface, spike_col, pts)
            pygame.draw.polygon(surface, frame_col,  pts, 1)

        # Use door sprite if available, else draw primitives
        if self.door_img and not locked:
            di = self.door_img.copy(); di.set_alpha(self.alpha)
            surface.blit(di, (x + w//2 - di.get_width()//2,
                              y + h//2 - di.get_height()//2 - 10))
        elif self.door_img and locked:
            grey = self.door_img.copy()
            grey.set_alpha(int(self.alpha * 0.35))
            surface.blit(grey, (x + w//2 - grey.get_width()//2,
                                y + h//2 - grey.get_height()//2 - 10))
        else:
            # Drawn fallback door
            im = 14; ix = x+im; iy = y+24; iw = w-im*2; ih = h-58
            arch = pygame.Rect(ix, iy - iw//5, iw, iw//2)
            pygame.draw.ellipse(surface, door_col,  arch)
            pygame.draw.ellipse(surface, frame_col, arch, 2)
            pygame.draw.rect(surface, door_col,  (ix, iy, iw, ih))
            pygame.draw.rect(surface, frame_col, (ix, iy, iw, ih), 2)
            pygame.draw.circle(surface, frame_col, (ix+iw-10, iy+ih//2), 4)

        # Lock icon
        if locked:
            lx = x + w//2; ly = y + h//2 + 5
            pygame.draw.rect(surface,  frame_col, (lx-10, ly,    20, 15), 0)
            pygame.draw.rect(surface,  door_col,  (lx-10, ly,    20, 15), 0)
            pygame.draw.rect(surface,  frame_col, (lx-10, ly,    20, 15), 2)
            pygame.draw.arc(surface,   frame_col,
                            pygame.Rect(lx-8, ly-13, 16, 18), 0, math.pi, 3)
            pygame.draw.circle(surface, door_col,  (lx, ly+7), 3)
            pygame.draw.rect(surface,   door_col,  (lx-2, ly+7, 4, 5))

        # Level label
        num = self.font_door_num.render(f"LEVEL {label}", True, num_col)
        num.set_alpha(self.alpha)
        surface.blit(num, (x + w//2 - num.get_width()//2, y + h - 22))

        # Selection arrow below
        if selected and self.show_arrow:
            arr = self.font_option.render("▲", True, self.C_ARROW)
            arr.set_alpha(self.alpha)
            surface.blit(arr, (x + w//2 - arr.get_width()//2, y + h + 6))

    # ---- MECHANICS -------------------------------------------------- #
    def _draw_mechanics(self, surface):
        self._draw_subscreen_bg(surface, "MECHANICS")
        px, py = 130, 135
        for i, (lbl, desc) in enumerate(self.mechanics_lines):
            ry = py + i * 52
            ls = self.font_body.render(lbl, True, self.C_TITLE)
            ls.set_alpha(self.alpha)
            cw = ls.get_width() + 16
            chip = pygame.Surface((cw, 24), pygame.SRCALPHA); chip.fill((0, 80, 100, 190))
            surface.blit(chip, (px, ry)); surface.blit(ls, (px+8, ry+3))
            ds = self.font_body.render(desc, True, self.C_BODY)
            ds.set_alpha(self.alpha); surface.blit(ds, (px+cw+18, ry+3))
        self._draw_back_hint(surface)

    # ---- DEVELOPERS ------------------------------------------------- #
    def _draw_developers(self, surface):
        self._draw_subscreen_bg(surface, "DEVELOPERS")
        cx, sy = screen_width // 2, 148
        for i, line in enumerate(self.dev_lines):
            color = self.C_TITLE if i == 0 else self.C_BODY
            font  = self.font_option if i == 0 else self.font_body
            s     = font.render(line, True, color)
            s.set_alpha(self.alpha)
            surface.blit(s, (cx - s.get_width()//2, sy + i*36))
        self._draw_back_hint(surface)

    # ---- HELPERS ---------------------------------------------------- #
    def _draw_subscreen_bg(self, surface, title_text):
        self._blit_bg(surface)
        dim = pygame.Surface((screen_width, screen_height), pygame.SRCALPHA)
        dim.fill((0, 0, 0, 165)); dim.set_alpha(self.alpha); surface.blit(dim, (0, 0))
        panel = pygame.Surface((screen_width-100, screen_height-100), pygame.SRCALPHA)
        panel.fill((10, 30, 42, 220)); surface.blit(panel, (50, 50))
        pygame.draw.rect(surface, self.C_BORDER, (50, 50, screen_width-100, screen_height-100), 2)
        t = self.font_option.render(title_text, True, self.C_TITLE)
        t.set_alpha(self.alpha); surface.blit(t, (screen_width//2 - t.get_width()//2, 66))
        pygame.draw.line(surface, self.C_BORDER, (70, 110), (screen_width-70, 110), 1)

    def _draw_back_hint(self, surface):
        b = self.font_back.render("[ ENTER / ESC  —  back ]", True, self.C_HINT)
        b.set_alpha(self.alpha)
        surface.blit(b, (screen_width//2 - b.get_width()//2, screen_height-70))


# ================================================================== #
#  GAME
# ================================================================== #
class Game:
    def __init__(self):
        self.loading    = LoadingScreen()
        self.menu       = StartMenu()
        self.player     = Player(150, 200)
        self.world      = World(level_1)
        self.running    = True
        self.state      = "loading"   # "loading" | "menu" | "playing"

    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False

            # Loading screen — skip on any key
            if self.state == "loading":
                if event.type == pygame.KEYDOWN:
                    self.loading.progress = 1.0

            # Menu
            elif self.state == "menu":
                consumed = self.menu.handle_input(event)
                if not consumed:
                    pass   # nothing passes through while menu is up

            # Playing
            elif self.state == "playing":
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_SPACE and self.player.VELOCITY_Y == 0:
                        self.player.VELOCITY_Y = -8
                    if event.key == pygame.K_RETURN and self.player.dead:
                        self.world.reset()
                        self.player.reset()
                    if event.key == pygame.K_ESCAPE:
                        # Return to menu
                        self.menu.reopen()
                        self.state = "menu"

    def update(self):
        if self.state == "loading":
            self.loading.update()
            if self.loading.done:
                # Small pause then fade into menu
                self.state = "menu"

        elif self.state == "menu":
            self.menu.update()
            # Transition: menu faded out → start playing
            if not self.menu.active and self.menu.start_game:
                idx          = self.menu.current_level
                spawn        = level_spawns[idx]
                self.player  = Player(spawn[0], spawn[1])
                self.world   = World(level_worlds[idx])
                self.menu.start_game = False
                self.state   = "playing"

        elif self.state == "playing":
            self.player.movement(self.world)

            for p in self.player.particles[:]:
                p.update(self.world.platforms)
                if not p.active:
                    self.player.particles.remove(p)

            self.world.update(self.player)

            # Level complete
            if self.world.door_with_player.done:
                self.world.door_with_player.done = False
                completed = self.menu.current_level
                self.menu.unlock_level(completed)
                nxt = completed + 1
                if nxt < len(level_worlds):
                    self.menu.current_level  = nxt
                    self.menu.selected_level = nxt
                self.menu.reopen()
                self.state = "menu"

    def draw(self):
        if self.state == "loading":
            screen.fill((5, 18, 25))
            self.loading.draw(screen)

        elif self.state == "menu":
            screen.fill((5, 18, 25))
            # Show game world faintly behind menu if already loaded
            self.menu.draw(screen)

        elif self.state == "playing":
            screen.fill("#0088aa")
            self.world.draw()
            for p in self.player.particles:
                p.draw(screen)
            self.player.draw(screen)

    def run(self):
        while self.running:
            self.handle_events()
            self.update()
            self.draw()
            pygame.display.update()
            clock.tick(60)


# ================================================================== #
#  ENTRY POINT
# ================================================================== #
game = Game()
game.run()
pygame.quit()