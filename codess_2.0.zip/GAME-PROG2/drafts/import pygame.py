import pygame
from pygame.locals import *
import os

pygame.init()

# ───────────────────────── SCREEN ─────────────────────────
screen_width = 800
screen_height = 600
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("WHAT")

clock = pygame.time.Clock()
tile_size = 32


# ───────────────────────── PLAYER ─────────────────────────
class Player(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()

        self.start_x = x
        self.start_y = y

        # images
        self.player_static_r = pygame.transform.scale(
            pygame.image.load(os.path.join("image_s", "static.png")), (32, 36)
        )

        self.player_moving_r = [
            pygame.transform.scale(pygame.image.load(os.path.join("image_s", f"move_{i}.png")), (32, 36))
            for i in range(1, 5)
        ]

        self.player_static_l = pygame.transform.flip(self.player_static_r, True, False)
        self.player_moving_l = [pygame.transform.flip(img, True, False) for img in self.player_moving_r]

        self.image = self.player_static_r
        self.rect = self.image.get_rect(topleft=(x, y))

        self.vel_x = 0
        self.vel_y = 0

        self.direction = "right"
        self.state = "static"

        self.frame_index = 0
        self.animation_speed = 0.2

        self.moving = False

    def movement(self, platforms):
        keys = pygame.key.get_pressed()
        self.moving = False
        self.vel_x = 0

        # LEFT / RIGHT
        if keys[K_LEFT]:
            self.vel_x = -5
            self.direction = "left"
            self.moving = True

        if keys[K_RIGHT]:
            self.vel_x = 5
            self.direction = "right"
            self.moving = True

        # X movement + collision
        self.rect.x += self.vel_x
        self.check_collision_x(platforms)

        # GRAVITY
        self.vel_y += 0.8
        if self.vel_y > 10:
            self.vel_y = 10

        self.rect.y += self.vel_y
        self.check_collision_y(platforms)

        # STATE
        if self.vel_y != 0:
            self.state = "jump"
        elif self.moving:
            self.state = "walk"
        else:
            self.state = "static"

        self.animate()

    def check_collision_x(self, platforms):
        for tile in platforms:
            if self.rect.colliderect(tile.rect):
                if self.vel_x > 0:
                    self.rect.right = tile.rect.left
                elif self.vel_x < 0:
                    self.rect.left = tile.rect.right

    def check_collision_y(self, platforms):
        for tile in platforms:
            if self.rect.colliderect(tile.rect):
                if self.vel_y > 0:
                    self.rect.bottom = tile.rect.top
                    self.vel_y = 0
                elif self.vel_y < 0:
                    self.rect.top = tile.rect.bottom
                    self.vel_y = 0

    def animate(self):
        if self.state == "walk":
            self.frame_index += self.animation_speed
            if self.frame_index >= len(self.player_moving_r):
                self.frame_index = 0

            img = self.player_moving_r if self.direction == "right" else self.player_moving_l
            self.image = img[int(self.frame_index)]

        elif self.state == "jump":
            self.image = self.player_moving_r[1] if self.direction == "right" else self.player_moving_l[1]

        else:
            self.image = self.player_static_r if self.direction == "right" else self.player_static_l

    def reset(self):
        self.rect.topleft = (self.start_x, self.start_y)
        self.vel_x = 0
        self.vel_y = 0


# ───────────────────────── TILE ─────────────────────────
class Tile(pygame.sprite.Sprite):
    def __init__(self, x, y, image):
        super().__init__()
        self.image = image
        self.rect = self.image.get_rect(topleft=(x, y))


# ───────────────────────── SPIKE ─────────────────────────
class Spike(pygame.sprite.Sprite):
    def __init__(self, x, y, image):
        super().__init__()
        self.image = image
        self.rect = self.image.get_rect(topleft=(x, y + (32 - 7)))
        self.rect.height = 7

    def update(self, player):
        if self.rect.colliderect(player.rect):
            player.reset()


# ───────────────────────── FALLING BLOCK ─────────────────────────
class Falling_Block(Tile):
    def __init__(self, x, y, image, speed):
        super().__init__(x, y, image)
        self.speed = speed
        self.falling = False
        self.trigger_range = 50

    def update(self, player):
        if abs(player.rect.centerx - self.rect.centerx) <= self.trigger_range:
            self.falling = True

        if self.falling:
            self.rect.y += self.speed


# ───────────────────────── WORLD ─────────────────────────
class World:
    def __init__(self, data):
        self.platforms = pygame.sprite.Group()
        self.falling_blocks = pygame.sprite.Group()
        self.spikes = pygame.sprite.Group()

        tile_surface = pygame.Surface((tile_size, tile_size))
        tile_surface.fill("#003a49")

        spike_img = pygame.transform.scale(
            pygame.image.load(os.path.join("image_s", "spike_static.png")), (32, 7)
        )

        for row_index, row in enumerate(data):
            for col_index, tile in enumerate(row):

                x = col_index * tile_size
                y = row_index * tile_size

                if tile == 1:
                    self.platforms.add(Tile(x, y, tile_surface))

                elif tile == 2:
                    self.falling_blocks.add(Falling_Block(x, y, tile_surface, 3))

                elif tile == 3:
                    self.spikes.add(Spike(x, y, spike_img))


    def draw(self, surface):
        self.platforms.draw(surface)
        self.falling_blocks.draw(surface)
        self.spikes.draw(surface)


    def update(self, player):
        self.falling_blocks.update(player)
        self.spikes.update(player)


# ───────────────────────── LEVEL DATA ─────────────────────────
world_data = [
    [1]*25,
    [1]*25,
    [1]*25,
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,0,1,3,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,1,1,1,1,1,1,1,1,1,1,1,2,1,1,1,1,1,1,1,1,1,1,1,1],
    [1]*25,
    [1]*25,
    [1]*25,
]


# ───────────────────────── INIT ─────────────────────────
player = Player(150, 200)
world = World(world_data)


# ───────────────────────── MAIN LOOP ─────────────────────────
run = True
while run:

    screen.fill("#0088aa")

    player.movement(world.platforms)

    world.update(player)

    world.draw(screen)
    screen.blit(player.image, player.rect)

    for event in pygame.event.get():
        if event.type == QUIT:
            run = False

        if event.type == KEYDOWN:
            if event.key == K_SPACE and player.vel_y == 0:
                player.vel_y = -14

    pygame.display.update()
    clock.tick(60)

pygame.quit()